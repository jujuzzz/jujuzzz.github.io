package dbController;

import java.sql.Connection;

import com.mysql.cj.xdevapi.Statement;

import main.Application;
import model.Album;

public class AlbumController {
	public void addAlbum(Album album) {
		Application connection = new Application();
		Connection conn = null;
		Statement sta = null;
		
		try {
	        conn = connection.getConnection();
	        sta = conn.createStatement();
	        String sql = "INSERT INTO `photos`.`album` (``, `color`, `condition`, `description`, `iName`,  `currentBid`)  VALUES ('"
	        		+ item.getMaterial()
	                + "','"
	                + item.getColor()
	                + "','"	        		
	                + item.getCondition()
	                + "','"	                
	                + item.getDescription()
	                + "','"	        		
	                + item.getName()
	                + "','"	        		
	                + item.getPrice()
	                + "')";
	     
	        
	        System.out.println(sql);
	       

	        sta.executeUpdate(sql);


	    } catch (SQLException e) {

	        e.printStackTrace();
	    } finally {
	        itemConnection.closeConnection(sta, conn);
	    }
	    
	
		
	}

}
