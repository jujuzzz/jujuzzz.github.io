package model;

import java.util.HashSet;
import java.util.Set;

public class PersonTag {

    private String value;
	private Set<Photo> mPhotos = new HashSet<>();
    public PersonTag(String tagvalue) {
    	value = tagvalue;

    }

    public void add(Photo photo) {
        mPhotos.add(photo);
    }

    public void remove(Photo photo) {
        mPhotos.remove(photo);
    }

}