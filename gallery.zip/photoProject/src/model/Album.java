package model;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class Album {
	private String albumname;
	private File thumbnail;
	private List<Photo> photolist = new ArrayList<>();
	
	
	public File getThumbnail() {
		return thumbnail;
	}
	public void setThumbnail(File thumbnail) {
		this.thumbnail = thumbnail;
	}
	
	public String getAlbumname() {
		return albumname;
	}
	public void setAlbumname(String albumname) {
		this.albumname = albumname;
	}
	public List<Photo> getPhotolist() {
		return photolist;
	}
	public void setPhotolist(List<Photo> photolist) {
		this.photolist = photolist;
	}
	
	public Album(String albumname) {
		this.albumname = albumname;
	}
	
	public void addPhoto(Photo photo) {
        if (!photolist.contains(photo)) {
        	photolist.add(photo);
        }
    }

    public void removePhoto(Photo photo) {
    	photolist.remove(photo);
    }
	

}
