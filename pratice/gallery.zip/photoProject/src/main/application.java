package main;

import java.io.File;

import helper.AlbumHelper;
import helper.LocationtagHelper;
import helper.PersontagHelper;
import helper.PhotoHelper;
import model.Album;
import model.LocationTag;
import model.PersonTag;
import model.Photo;

public class application {
	public static void main(String[] args)  {
		Album album = new Album("juju");
		Album oldalbum = new Album("gougou");
		File testpic = new File("/User/juju/Desktop/gou.png");
		Photo photo = new Photo(testpic, "juju");
		//PersonTag ptag = new PersonTag("choude", "/User/juju/Desktop/gou.png");
		//PersonTag ptagb = new PersonTag("xiangde", "abc");
		LocationTag ltag = new LocationTag("choude", "/User/juju/Desktop/gou.png");
		LocationTag ltagb = new LocationTag("xiangde", "abc");
		//AlbumHelper.addalbum(album); 
		//PhotoHelper.getallphoto(); 
	    //PersontagHelper.addpersontag(ptagb);
		//PersontagHelper.getphotopersontag(photo);
		//PersontagHelper.getallpersontag();
		//LocationtagHelper.addlocationtag(ltag);
		//LocationtagHelper.addlocationtag(ltagb);
		//LocationtagHelper.getalllocationtag();
		//LocationtagHelper.getphotolocationtag(photo);
		LocationtagHelper.deletepersontag(ltagb);
		
		
		
	}

}
