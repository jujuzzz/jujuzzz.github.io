package helper;

import java.io.File;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import dbConnection.dbConnection;
import model.Album;
import model.Photo;

public class PhotoHelper {
	public static void addphoto(Photo photo) {
		System.out.println("enter addphoto");
		dbConnection connection = new dbConnection();
		Connection conn = null;
		Statement sta = null;
		try {
	        conn = connection.getConnection();
	        sta = conn.createStatement();
	        String sql = "INSERT INTO `photos`.`photo` (`filepath`,`albumid`)  VALUES ('"
	        		+ photo.getImage().getPath()
	        		+ "','"
	                + photo.getAlbumid()
	                + "');";
	        System.out.println("sql execution instruction is " + sql);
	        sta.executeUpdate(sql);

	    } catch (SQLException e) {

	        e.printStackTrace();
	    } finally {
	        connection.closeConnection(sta, conn);
	    }
	   		
	}
	
	public static void deletephoto(Photo photo) {
		dbConnection connection = new dbConnection();
		Connection conn = null;
		Statement sta = null;
		
		try {
	        conn = connection.getConnection();
	        sta = conn.createStatement();
	        String sql = "DELETE FROM `photos`.`photo` WHERE `albumid` ='"
	        		+ photo.getAlbumid() 
	        		+ "' and `filepath` = '"
	                + photo.getImage().getPath()              
	                + "';";	
	        System.out.println("sql execution instruction is " + sql);
	        sta.executeUpdate(sql);
	        


	    } catch (SQLException e) {

	        e.printStackTrace();
	    } finally {
	        connection.closeConnection(sta, conn);
	    }
	}
	
	public static void movephoto(Album oldalbum, Album newalbum, Photo photo) {
		System.out.println("enter addphoto");
		dbConnection connection = new dbConnection();
		Connection conn = null;
		Statement sta = null;
		try {
	        conn = connection.getConnection();
	        sta = conn.createStatement();
	        String sql = "INSERT INTO `photos`.`photo` (`filepath`,`albumid`)  VALUES ('"
	        		+ photo.getImage().getPath()
	        		+ "','"
	                + newalbum.getAlbumname()
	                + "');";
	        System.out.println("sql execution instruction is " + sql);
	        sta.executeUpdate(sql);
	        
	        
	        String newsql = "DELETE FROM `photos`.`photo` WHERE `albumid` ='"
	        		+ oldalbum.getAlbumname() 
	        		+ "' and `filepath` = '"
	                + photo.getImage().getPath()              
	                + "';";	
	        System.out.println("sql execution instruction is " + newsql);
	        sta.executeUpdate(newsql);

	    } catch (SQLException e) {

	        e.printStackTrace();
	    } finally {
	        connection.closeConnection(sta, conn);
	    }
	   		
	}
	
	public static List<Photo> getalbumphoto(Album album) {
		dbConnection connection = new dbConnection();
		Connection conn = null;
		Statement sta = null;
		List<Photo> photolist = new ArrayList<>(); 
		
		try {
	        conn = connection.getConnection();
	        sta = conn.createStatement();
	        String sql = "SELECT * FROM `photos`.`photo` WHERE `albumid` = '"
	        		+ album.getAlbumname()
	        		+ "';";	
	        System.out.println("sql execution instruction is " + sql);
	        ResultSet rs =  sta.executeQuery(sql);	        
	        while (rs.next()) {	        	
	        	Photo photo = new Photo(new File(rs.getString(2)), rs.getString(1));	        	
	        	photolist.add(photo);	        	
	        }
	        System.out.println("size of result list is " + photolist.size());
	        for (Photo photopath:photolist) {	        	
	        	System.out.println(photopath.getImage().getAbsolutePath());
	        	System.out.println(photopath.getAlbumid());
	        }
	    } catch (SQLException e) {

	        e.printStackTrace();
	    } finally {
	        connection.closeConnection(sta, conn);
	    }
		return photolist;
	}
	
	
	public static List<Photo> getallphoto() {
		dbConnection connection = new dbConnection();
		Connection conn = null;
		Statement sta = null;
		List<Photo> photolist = new ArrayList<>(); 
		
		try {
	        conn = connection.getConnection();
	        sta = conn.createStatement();
	        String sql = "SELECT * FROM `photos`.`photo`;";	        			
	        System.out.println("sql execution instruction is " + sql);
	        ResultSet rs =  sta.executeQuery(sql);	        
	        while (rs.next()) {	        	
	        	Photo photo = new Photo(new File(rs.getString(2)), rs.getString(1));	        	
	        	photolist.add(photo);	        	
	        }
	        System.out.println("size of result list is " + photolist.size());
	        for (Photo photopath:photolist) {	        	
	        	System.out.println(photopath.getImage().getAbsolutePath());
	        	System.out.println(photopath.getAlbumid());
	        }
	    } catch (SQLException e) {

	        e.printStackTrace();
	    } finally {
	        connection.closeConnection(sta, conn);
	    }
		return photolist;
	}

}
