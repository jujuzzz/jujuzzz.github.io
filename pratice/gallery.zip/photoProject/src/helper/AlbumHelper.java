package helper;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import dbConnection.dbConnection;

import java.sql.SQLException;

import model.Album;

public class AlbumHelper {
	public static void addalbum(Album album) {
		System.out.println("enter addalbum");
		dbConnection connection = new dbConnection();
		Connection conn = null;
		Statement sta = null;
		
		try {
	        conn = connection.getConnection();
	        sta = conn.createStatement();
	        String sql = "INSERT INTO `photos`.`album` (`albumname`)  VALUES ('"
	        		+ album.getAlbumname()	                
	                + "');";
	        System.out.println("sql execution instruction is " + sql);
	        sta.executeUpdate(sql);


	    } catch (SQLException e) {

	        e.printStackTrace();
	    } finally {
	        connection.closeConnection(sta, conn);
	    }
	   		
	}
	
	public static void deletealbum(Album album) {
		dbConnection connection = new dbConnection();
		Connection conn = null;
		Statement sta = null;
		
		try {
	        conn = connection.getConnection();
	        sta = conn.createStatement();
	        String sql = "DELETE FROM `photos`.`album` WHERE (`albumname`) ='"
	        		+ album.getAlbumname()	                
	                + "';";	     	        	     	       
	        sta.executeUpdate(sql);


	    } catch (SQLException e) {

	        e.printStackTrace();
	    } finally {
	        connection.closeConnection(sta, conn);
	    }
	}
	
	public static void renamealbum(Album album, String newname) {
		dbConnection connection = new dbConnection();
		Connection conn = null;
		Statement sta = null;
		
		try {
	        conn = connection.getConnection();
	        sta = conn.createStatement();
	        String sql = "UPDATE `photos`.`album` SET `albumname` = '"
	        		+ newname
	        		+ "' WHERE `albumname` = '"
	        		+ album.getAlbumname()	        		
	                + "';";	     	        	     	       
	        sta.executeUpdate(sql);


	    } catch (SQLException e) {

	        e.printStackTrace();
	    } finally {
	        connection.closeConnection(sta, conn);
	    }
	}
	
	public static List<Album> getallalbum() {
		dbConnection connection = new dbConnection();
		Connection conn = null;
		Statement sta = null;
		List<Album> albumlist = new ArrayList<>();
		
		try {
	        conn = connection.getConnection();
	        sta = conn.createStatement();
	        String sql = "SELECT * FROM `photos`.`album`;";	
	        ResultSet rs =  sta.executeQuery(sql);	        
	        while (rs.next()) {
	        	Album album = new Album(rs.getString(1));
	        	albumlist.add(album);	        	
	        }
	        for (Album albumname:albumlist) {
	        	System.out.println(albumname);
	        }
	    } catch (SQLException e) {

	        e.printStackTrace();
	    } finally {
	        connection.closeConnection(sta, conn);
	    }
		return albumlist;
	}
	

}
