package helper;


import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashSet;
import java.util.Set;
import dbConnection.dbConnection;
import model.PersonTag;
import model.Photo;

public class PersontagHelper {
	public static void addpersontag(PersonTag tag) {
		System.out.println("enter addpersontag");
		dbConnection connection = new dbConnection();
		Connection conn = null;
		Statement sta = null;
		try {
	        conn = connection.getConnection();
	        sta = conn.createStatement();
	        String sql = "INSERT INTO `photos`.`persontag` (`photoid`,`value`)  VALUES ('"
	        		+ tag.getPhotoid()
	        		+ "','"
	                + tag.getValue()
	                + "');";
	        System.out.println("sql execution instruction is " + sql);
	        sta.executeUpdate(sql);

	    } catch (SQLException e) {

	        e.printStackTrace();
	    } finally {
	        connection.closeConnection(sta, conn);
	    }
	   		
	}
	
	public static void deletepersontag(PersonTag tag) {
		dbConnection connection = new dbConnection();
		Connection conn = null;
		Statement sta = null;
		
		try {
	        conn = connection.getConnection();
	        sta = conn.createStatement();
	        String sql = "DELETE FROM `photos`.`persontag` WHERE `photoid` ='"
	        		+ tag.getPhotoid() 
	        		+ "' and `value` = '"
	                + tag.getValue()              
	                + "';";	
	        System.out.println("sql execution instruction is " + sql);
	        sta.executeUpdate(sql);
	        
	    } catch (SQLException e) {

	        e.printStackTrace();
	    } finally {
	        connection.closeConnection(sta, conn);
	    }
	}
	
	public static Set<PersonTag> getphotopersontag(Photo photo) {
		dbConnection connection = new dbConnection();
		Connection conn = null;
		Statement sta = null;
		Set<PersonTag> taglist = new HashSet<>(); 
		
		try {
	        conn = connection.getConnection();
	        sta = conn.createStatement();
	        String sql = "SELECT * FROM `photos`.`persontag` WHERE `photoid` = '"
	        		+ photo.getImage().getPath()
	        		+ "';";	
	        System.out.println("sql execution instruction is " + sql);
	        ResultSet rs =  sta.executeQuery(sql);	        
	        while (rs.next()) {	        	
	        	PersonTag tag = new PersonTag(rs.getString(2), rs.getString(1));	        	
	        	taglist.add(tag);	        	
	        }
	        System.out.println("size of result list is " + taglist.size());
	        for (PersonTag tagname: taglist) {	        		        	
	        	System.out.println(tagname.getValue());
	        	System.out.println(tagname.getPhotoid());
	        }
	    } catch (SQLException e) {

	        e.printStackTrace();
	    } finally {
	        connection.closeConnection(sta, conn);
	    }
		return taglist;
	}
	
	
	public static Set<PersonTag> getallpersontag() {
		dbConnection connection = new dbConnection();
		Connection conn = null;
		Statement sta = null;
		Set<PersonTag> taglist = new HashSet<>(); 
		
		try {
	        conn = connection.getConnection();
	        sta = conn.createStatement();
	        String sql = "SELECT * FROM `photos`.`persontag`;";
	        		
	        System.out.println("sql execution instruction is " + sql);
	        ResultSet rs =  sta.executeQuery(sql);	        
	        while (rs.next()) {	        	
	        	PersonTag tag = new PersonTag(rs.getString(2), rs.getString(1));	        	
	        	taglist.add(tag);	        	
	        }
	        System.out.println("size of result list is " + taglist.size());
	        for (PersonTag tagname: taglist) {	        		        	
	        	System.out.println(tagname.getValue());
	        	System.out.println(tagname.getPhotoid());
	        }
	    } catch (SQLException e) {

	        e.printStackTrace();
	    } finally {
	        connection.closeConnection(sta, conn);
	    }
		return taglist;
	}
	

}
