package helper;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashSet;
import java.util.Set;

import dbConnection.dbConnection;
import model.LocationTag;
import model.Photo;

public class LocationtagHelper {
	public static void addlocationtag(LocationTag tag) {
		System.out.println("enter addpersontag");
		dbConnection connection = new dbConnection();
		Connection conn = null;
		Statement sta = null;
		try {
	        conn = connection.getConnection();
	        sta = conn.createStatement();
	        String sql = "INSERT INTO `photos`.`locationtag` (`photoname`,`value`)  VALUES ('"
	        		+ tag.getPhotoid()
	        		+ "','"
	                + tag.getValue()
	                + "');";
	        System.out.println("sql execution instruction is " + sql);
	        sta.executeUpdate(sql);

	    } catch (SQLException e) {

	        e.printStackTrace();
	    } finally {
	        connection.closeConnection(sta, conn);
	    }
	   		
	}
	
	public static void deletepersontag(LocationTag tag) {
		dbConnection connection = new dbConnection();
		Connection conn = null;
		Statement sta = null;
		
		try {
	        conn = connection.getConnection();
	        sta = conn.createStatement();
	        String sql = "DELETE FROM `photos`.`locationtag` WHERE `photoname` ='"
	        		+ tag.getPhotoid() 
	        		+ "' and `value` = '"
	                + tag.getValue()              
	                + "';";	
	        System.out.println("sql execution instruction is " + sql);
	        sta.executeUpdate(sql);
	        
	    } catch (SQLException e) {

	        e.printStackTrace();
	    } finally {
	        connection.closeConnection(sta, conn);
	    }
	}
	
	public static Set<LocationTag> getphotolocationtag(Photo photo) {
		dbConnection connection = new dbConnection();
		Connection conn = null;
		Statement sta = null;
		Set<LocationTag> taglist = new HashSet<>(); 
		
		try {
	        conn = connection.getConnection();
	        sta = conn.createStatement();
	        String sql = "SELECT * FROM `photos`.`locationtag` WHERE `photoname` = '"
	        		+ photo.getImage().getPath()
	        		+ "';";	
	        System.out.println("sql execution instruction is " + sql);
	        ResultSet rs =  sta.executeQuery(sql);	        
	        while (rs.next()) {	        	
	        	LocationTag tag = new LocationTag(rs.getString(2), rs.getString(1));	        	
	        	taglist.add(tag);	        	
	        }
	        System.out.println("size of result list is " + taglist.size());
	        for (LocationTag tagname: taglist) {	        		        	
	        	System.out.println(tagname.getValue());
	        	System.out.println(tagname.getPhotoid());
	        }
	    } catch (SQLException e) {

	        e.printStackTrace();
	    } finally {
	        connection.closeConnection(sta, conn);
	    }
		return taglist;
	}
	
	
	public static Set<LocationTag> getalllocationtag() {
		dbConnection connection = new dbConnection();
		Connection conn = null;
		Statement sta = null;
		Set<LocationTag> taglist = new HashSet<>(); 
		
		try {
	        conn = connection.getConnection();
	        sta = conn.createStatement();
	        String sql = "SELECT * FROM `photos`.`locationtag`;";
	        		
	        System.out.println("sql execution instruction is " + sql);
	        ResultSet rs =  sta.executeQuery(sql);	        
	        while (rs.next()) {	        	
	        	LocationTag tag = new LocationTag(rs.getString(2), rs.getString(1));	        	
	        	taglist.add(tag);	        	
	        }
	        System.out.println("size of result list is " + taglist.size());
	        for (LocationTag tagname: taglist) {	        		        	
	        	System.out.println(tagname.getValue());
	        	System.out.println(tagname.getPhotoid());
	        }
	    } catch (SQLException e) {

	        e.printStackTrace();
	    } finally {
	        connection.closeConnection(sta, conn);
	    }
		return taglist;
	}
	


}
