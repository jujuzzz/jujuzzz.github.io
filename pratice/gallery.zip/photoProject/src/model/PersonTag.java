package model;

import java.util.HashSet;
import java.util.Set;

public class PersonTag {

    private String value;
	private String photoid;
    
	public PersonTag(String tagvalue, String photoid) {
    	value = tagvalue;
    	this.photoid = photoid;

    }

    public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
		
	}

	public String getPhotoid() {
		return photoid;
	}

	public void setPhotoid(String photoid) {
		this.photoid = photoid;
	}

	

}