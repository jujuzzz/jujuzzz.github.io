package model;

import java.io.File;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Photo {

	private File image;
	private String albumid;
	public String getAlbumid() {
		return albumid;
	}

	public void setAlbumid(String albumid) {
		this.albumid = albumid;
	}

	//List allows duplicate element while Set doesn't 
	private Set<PersonTag> persontag = new HashSet<>();
	private Set<LocationTag> locationtag = new HashSet<>();
	
	public Photo(File picture, String album) {
        this.image = picture;
        this.albumid = album;
    }
	
	public File getImage() {
		return image;
	}

	public void setImage(File image) {
		this.image = image;
	}

	public Set<PersonTag> getPersontag() {
		return persontag;
	}

	public void setPersontag(Set<PersonTag> persontag) {
		this.persontag = persontag;
	}

	public Set<LocationTag> getLocationtag() {
		return locationtag;
	}

	public void setLocationtag(Set<LocationTag> locationtag) {
		this.locationtag = locationtag;
	}

	public void addPersonTag(PersonTag personTag) {
        persontag.add(personTag);
        personTag.setPhotoid(image.getPath());
    }


	public void removePersonTag(PersonTag personTag) {
        persontag.remove(personTag);
        personTag.setPhotoid("");
    }

    public void addLocationTag(LocationTag locationTag) {
        locationtag.add(locationTag);
        locationTag.setPhotoid(image.getPath());
    }

    public void removeLocationTag(LocationTag locationTag) {
        locationtag.remove(locationTag);
        locationTag.setPhotoid(image.getPath());
    }
}
