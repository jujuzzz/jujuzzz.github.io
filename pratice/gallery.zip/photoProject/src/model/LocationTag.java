package model;

import java.util.HashSet;
import java.util.Set;

public class LocationTag {
    private String value;
private String photoid;
    
	public LocationTag(String tagvalue, String photoid) {
    	value = tagvalue;
    	this.photoid = photoid;

    }

    public String getValue() {
		return value;
	}

	public void setValue(String value, String photoid) {
		this.value = value;
		this.photoid = photoid;
	}

	public String getPhotoid() {
		return photoid;
	}

	public void setPhotoid(String photoid) {
		this.photoid = photoid;
	}

}