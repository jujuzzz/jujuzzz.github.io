package controller;

public class AlbumController {

}
