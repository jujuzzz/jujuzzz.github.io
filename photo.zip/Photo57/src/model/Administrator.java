package model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.ListIterator;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Alert;

public class Administrator implements Serializable {
	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1348924596455673918L;

	/**
	 * List of Users to store at the back end
	 */
	ArrayList<User> userList;
	
	/**
	 * List of Users to show at the front end
	 */
	static ObservableList<User> userListFrontEnd;
	
	/**
	 * Current user
	 */
	User currentUser;
	
	/**
	 * Constructor for initializing fields
	 */
	public Administrator(){
		userList = null;
		userListFrontEnd = FXCollections.observableArrayList();
		currentUser = null;
	}
	
	/**
	 * @return user list at the front end
	 */
	public ObservableList<User> getUserListFrontEnd(){
		return userListFrontEnd;
	}
	
	/**
	 * @return current user
	 */
	public User getCurrentUser(){
		return currentUser;
	}
	
	/**
	 * @param currentUser
	 */
	public void setCurrentUser(User currentUser){
		this.currentUser = currentUser;
	}
	
	/**
	 * Create new user
	 */
	public void createNewUser(String username){
		User user = new User(username);
		ListIterator<User> userIterator = userListFrontEnd.listIterator();
		
		while(true){
			if(userIterator.hasNext()){
				userIterator.add(user);
			}
			
			User userInList = userIterator.next();
			if(userInList.equals(user)){
				System.out.println("Username is not inserted into userList");
			}else{
				userIterator.previous();
				userIterator.add(user);
				System.out.println("Username is inserted into userList successfully");
			}
		}
	}
	
	/**
	 * Delete user at the designated index
	 * @param i
	 */
	public void deleteUser(int i){
		if(i >= 0 && i < userListFrontEnd.size()){
			if(!userListFrontEnd.get(i).getUsername().equalsIgnoreCase("admin")){
				userListFrontEnd.remove(i);
			}else{
				Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error");
                alert.setHeaderText("Deleting Admin detected");
                alert.setContentText("Admin cannot be deleted.");
                alert.showAndWait();
			}
		}
	}
	
	public static User retrieveUser(String username){
		return userListFrontEnd.stream().filter(user -> user.getUsername()
				.equalsIgnoreCase(username)).findFirst().orElse(null);
	}
}
