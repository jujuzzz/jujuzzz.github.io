package model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.ListIterator;
import java.util.stream.IntStream;

import model.Album;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Alert;

public class User implements Serializable {
	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 4703288367747854817L;

	/**
	 * Username
	 */
	String username;
	
	/**
	 * List of albums to store at the back end
	 * Setting different names is for avoiding duplicate names for front and back ends.
	 */
	ArrayList<Album> albumList;
	
	/**
	 * List of albums to show at the front end. 
	 * Setting different names is for avoiding duplicate names for front and back ends.
	 */
	ObservableList<Album> albumListFrontEnd;
	
	/**
	 * Current album
	 */
	Album currentAlbum;
	
	/**
	 * @param username
	 */
	public User(String username) {
		// TODO Auto-generated constructor stub
		this.username = username;
		albumList = null;
		albumListFrontEnd = FXCollections.observableArrayList();
		currentAlbum = null;
	}
	
	/**
	 * user name
	 * @return username
	 */
	public String getUsername(){
		return username;
	}
	
	public ObservableList<Album> getAlbumListFrontEnd(){
		return albumListFrontEnd;
	}
	
	/**
	 * current album
	 * @return current album
	 */
	public Album getCurrentAlbum(){
		return currentAlbum;
	}
	
	/**
	 * @param currentAlbum current album
	 */
	public void setCurrentAlbum(Album currentAlbum){
		this.currentAlbum = currentAlbum;
	}
	
	/**
	 * create new album
	 * @param albumName
	 * @return new album added
	 */
	public Album createAlbum(String albumName){
		Album album = new Album(albumName);
		ListIterator<Album> albumIterator = albumListFrontEnd.listIterator();
		
		while(true){
			if(albumIterator.hasNext()){
				albumIterator.add(album);
			}
			
			Album albumInList = albumIterator.next();
			if(albumInList.equals(albumName)){
				return null;
			}else{
				albumIterator.previous();
				albumIterator.add(album);
				return album;
			}
		}
		
	}

	/**
	 * delete the album at designated index
	 * @param i the designated index to be deleted
	 */
	public void deleteAlbum(int i){
		if(i >= 0 && i < albumListFrontEnd.size()){
			albumListFrontEnd.remove(i);
		}
	}
	
	/**
	 * @param i designated index of album to update
	 * @param newAlbumName new album name
	 */
	public void renameAlbum(int i, String newAlbumName){
		if (i >= 0 && i < albumListFrontEnd.size()) {
            boolean isFound = IntStream.range(0, albumListFrontEnd.size())
                    .filter(index -> index != i)
                    .anyMatch(index -> albumListFrontEnd.get(i).getAlbumNameBackEnd()
                    		.equalsIgnoreCase(newAlbumName));
            
			if (!isFound) {
				albumListFrontEnd.get(i).setAlbumNameBackEnd(newAlbumName);
			}
		}
	}
	
	public Album retrieveAlbum(String albumName){
		return albumListFrontEnd.stream().filter(user -> user.getAlbumNameBackEnd()
				.equalsIgnoreCase(albumName)).findFirst().orElse(null);
	}
	
	public String toString() {
		return username;
		
	}
}
