package model;

import java.io.Serializable;
import java.util.HashMap;

public class Tag implements Serializable {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 3430529772963736249L;
	
	/**
	 * tag name
	 */
	String tagName;
	
	/**
	 * tag value
	 */
	String tagValue;
	
	public Tag(String tagName, String tagValue){
		this.tagName = tagName;
		this.tagValue = tagValue;
	}
}
