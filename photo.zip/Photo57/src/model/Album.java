package model;

import java.io.File;
import java.io.Serializable;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.IntStream;

import model.Photo;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

public class Album implements Serializable {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -4143935150417416554L;
	
	/**
	 * album name. albumNameBackEnd is separate from SimpleStringProperty albumName. 
	 */
	String albumNameBackEnd;
	
	/**
	 * List of photos in an album
	 */
	List<Photo> photoList;
	
	/**
	 * Column of album name
	 */
	SimpleStringProperty albumName;
	
	/**
	 * Column of number of photos
	 */
	SimpleIntegerProperty numberOfPhotos;
	
	/**
	 * Column of earliest date
	 */
	SimpleStringProperty earliestDate;
	
	/**
	 * Column of latestDate
	 */
	SimpleStringProperty latestDate;
	
	/**
	 * Index of current photo
	 */
	int indexOfCurrentPhoto;
	
	/**
	 * Initialize album. This constructor should be called by front end.
	 * @param tempAlbumName album name
	 */
	public Album(String tempAlbumName){
		albumName = new SimpleStringProperty(tempAlbumName);
		numberOfPhotos = new SimpleIntegerProperty(0);
		earliestDate = new SimpleStringProperty(null);
		latestDate = new SimpleStringProperty(null);
	}
	
	public Album(){
    }
	/**
	 * album name
	 * @return album name
	 */
	public String getAlbumNameBackEnd(){
		return albumNameBackEnd;
	}
	
	/**
	 * @param albumNameBackEnd album name stored at the back end
	 */
	public void setAlbumNameBackEnd(String albumNameBackEnd){
		this.albumNameBackEnd = albumNameBackEnd;
	}
	
	/**
	 * List all photos in an album
	 * @return list of photos 
	 */
	public List<Photo> getPhotoList(){
		return photoList;
	}
	
	/**
     * @return Size of list of photos
     */
    public int getSize() {
    	return photoList.size();
    }
	
	/**
	 * @return name of album
	 */
	public String getAlbumName(){
		return albumName.get();
	}
	
	public SimpleStringProperty getAlbumTitle(){
		return albumName;
	}
	
	/**
	 * @param albumName album name
	 */
	public void setAlbumName(String albumName){
		this.albumName.set(albumName);
	}
	
	/**
	 * @return number of photos in an album
	 */
	public int getNumberOfPhotos(){
		return numberOfPhotos.get();
	}
	
	public SimpleIntegerProperty getPhotoNum(){
		return numberOfPhotos;
	}
	
	/**
	 * @param numberOfPhotos number of photos in an album
	 */
	public void setNumberOfPhotos(int numberOfPhotos){
		this.numberOfPhotos.set(numberOfPhotos);
	}
	
	/**
	 * @return earliest date on which photos were taken
	 */
	public String getEarliestDate(){
		return earliestDate.get();
	}
	
	/**
	 * @param earliestDate earliest date on which photos were taken
	 */
	public void setEarliestDate(String earliestDate){
		this.earliestDate.set(earliestDate);
	}

	/**
	 * @return latest date on which photos were taken
	 */
	public String getLatestDate(){
		return latestDate.get();
	}
	
	/**
	 * @param latestDate latest date on which photos were taken
	 */
	public void setLatestDate(String latestDate){
		this.latestDate.set(latestDate);
	}
	
	/**
	 * @return current photo
	 */
	public Photo getCurrentPhoto(){
		obtainIndexOfCurrentPhoto();
		
		if(indexOfCurrentPhoto > 0){
			return photoList.get(indexOfCurrentPhoto);
		}else{
			return null;
		}
	}
	
	/**
	 * @param photoFileName file name of the photo
	 * @param file photo file
	 * @return new photo object
	 */
	public void addPhoto(Photo photo){
		photoList.add(photo);
    	indexOfCurrentPhoto = photoList.size() - 1;
	}
	
	/**
	 * @param photo photo object
	 * @return designated index of photo to be deleted
	 */
	public int removePhoto(Photo photo){
		int indexToBeDeleted = -1;
		
		for(int i = 0; i < photoList.size(); i++){
			if(photo.equals(photoList.get(i))){
				indexToBeDeleted = i;
				photoList.remove(i);
			}
		}
		
		return indexToBeDeleted;
	}
	
	/**
	 * This method should be directly called by Album object from Album Controller
	 * @return index of current photo
	 */
	public int obtainIndexOfCurrentPhoto(){
		if(photoList.size() == 0){
			indexOfCurrentPhoto = -1;
		}else{
			if(indexOfCurrentPhoto > photoList.size()){
				indexOfCurrentPhoto = photoList.size() - 1;
			}else if(indexOfCurrentPhoto < 0){
				indexOfCurrentPhoto = 0;
			}
		}
		
		return indexOfCurrentPhoto;
	}
	
	/**
	 * This method should be directly called by Album object from Album Controller
	 * @param photoPositionOfPhotoToBeAdded the photo at an index where a new photo will be added
	 * @param photoToBeAdded new photo to be added
	 * @return
	 */
	public int addPhotoToAlbum(Photo photoPositionOfPhotoToBeAdded, Photo photoToBeAdded){
		int indexToBeAdded = -1;
		
		if(photoPositionOfPhotoToBeAdded.equals("")){
			indexToBeAdded = photoList.size();
		}else{
			indexToBeAdded = obtainPhotoIndex(photoPositionOfPhotoToBeAdded);
		}
		
		photoList.add(indexToBeAdded, photoToBeAdded);
		return indexToBeAdded;
	}
	
	/**
	 * @param inputIndex index of current photo
	 * @return inputIndex index of current photo
	 */
	public int configureIndexOfCurrentPhoto(int inputIndex){
		indexOfCurrentPhoto = inputIndex;
		return obtainIndexOfCurrentPhoto();
	}
	
	/**
	 * obtain photo object given index. 
	 * @param i index
	 * @return photo at that index
	 */
	public Photo obtainPhotoFromAlbum(int i){
		return photoList.get(i);
	}
	
	/**
	 * obtain index given photo object.
	 * @param photo photo
	 * @return index of the photo
	 */
	public int obtainPhotoIndex(Photo photo){
		return IntStream.range(0, photoList.size()).filter(i -> photo == photoList.get(i))
				.findFirst().orElse(-1);
	}
	
	/**
	 * Configure other three colummns other than album name in the album
	 */
	public void configureCountEarliestAndLatest(){
		if(photoList.size() == 0){
			setNumberOfPhotos(0);
			setEarliestDate("null");
			setLatestDate("null");
		}else{
			int numberOfPhotos = 0;
			long earliest = 0;
			long latest = 0;
			boolean isEarliest = true;
			
			for(Photo p : photoList){
				if(isEarliest){
					numberOfPhotos = 1;
					earliest = p.getDateOfPhoto();
					latest = p.getDateOfPhoto();
					isEarliest = false;
				}else{
					numberOfPhotos++;
					
					if(p.getDateOfPhoto() > latest){
						latest = p.getDateOfPhoto();
					}
					
					if(p.getDateOfPhoto() > earliest){
						earliest = p.getDateOfPhoto();
					}
				}
			}
			
			setNumberOfPhotos(numberOfPhotos);
			setEarliestDate(convertToLastModifiedTime(earliest));
			setLatestDate(convertToLastModifiedTime(latest));
		}
	}
	
	/**
	 * Convert last modified time into string
	 * @param time input time
	 * @return output formatted string
	 */
	public static String convertToLastModifiedTime(long time) {
        LocalDateTime datetime = LocalDateTime.ofInstant(Instant.ofEpochMilli(time), 
        		ZoneId.systemDefault());
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        
        return datetime.format(formatter);
    }
}
