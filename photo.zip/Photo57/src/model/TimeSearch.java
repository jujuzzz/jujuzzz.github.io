package model;

import java.io.Serializable;
import java.time.LocalDate;

/**
 * This class is for searching by time in an album
 * @author YuezhongYan
 *
 */
public class TimeSearch implements Serializable {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -6550615284411564064L;

	/**
	 * start date for range of dates
	 */
	LocalDate startDate = null;
	
	/**
	 * end date for range of dates
	 */
	LocalDate endDate = null;
	
	/**
	 * @return start date in a range of dates
	 */
	public LocalDate getStartDate(){
		return startDate;
	}
	
	/**
	 * @param startDate start date in a range of dates
	 */
	public void setStartDate(LocalDate startDate){
		this.startDate = startDate;
	}
	
	/**
	 * @return end date in a range of dates
	 */
	public LocalDate getEndDate(){
		return endDate;
	}
	
	public void setEndDate(LocalDate endDate){
		this.endDate = endDate;
	}
}
