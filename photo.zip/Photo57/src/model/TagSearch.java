package model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.ListIterator;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 * This class is for searching by tags in an album
 * @author YuezhongYan
 *
 */
public class TagSearch implements Serializable {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 6221328024591031220L;

	/**
	 * tag list to show at the front end
	 */
	ObservableList<Tag> tagListFrontEnd;
	
	/**
	 * tag list to store at the back end
	 */
	ArrayList<Tag> tagList;
	
	/**
	 * initialize tag search
	 */
	public TagSearch(){
		tagListFrontEnd = FXCollections.observableArrayList();
	}
	
	public ObservableList<Tag> getTagListFrontEnd(){
		return tagListFrontEnd;
	}
	
	public boolean addTag(String tagName, String tagValue){
		Tag tag = new Tag(tagName, tagValue);
		ListIterator<Tag> tagIterator = tagListFrontEnd.listIterator();
		
		while(true){
			if(!tagIterator.hasNext()){
				tagIterator.add(tag);
			}
			
			Tag tagInList = tagIterator.next();
			if(tagInList.equals(tag)){
				return false;
			}else{
				tagIterator.previous();
				tagIterator.add(tag);
				return true;
			}
		}
	}
}
