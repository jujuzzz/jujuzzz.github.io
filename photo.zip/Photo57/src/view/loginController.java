package view;

import java.net.URL;
import java.util.ResourceBundle;

import application.Photos;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import model.Administrator;
import model.User;


public class loginController implements Initializable {
	@FXML
	private Button adminlogin;	
	@FXML
	private TextField adminname;
	@FXML
	private TextField username;
	@FXML
	private Button userlogin;
		
	
	private Photos application;
    
    
    public void setApp(Photos application){
        this.application = application;
    }
    
    
    @FXML
    public void adminlogin(ActionEvent event) {
    	String administratorname = adminname.getText();
    	if (!administratorname.equals("") && username.getText().equals("")) {
    		User ad = Administrator.retrieveUser(administratorname);
    		if (ad != null) {
    			application.gotoadmin();
    		}else {
    			Alert alert = new Alert(AlertType.INFORMATION);
    			alert.setTitle("Warning");
    			alert.setHeaderText(null);
    			alert.setContentText("Username does not match!");
    			alert.showAndWait();
    		}   		
    		adminname.setText(null);
    	}else if(administratorname.equals("") && username.getText().equals("")){
    		Alert alert = new Alert(AlertType.INFORMATION);
			alert.setTitle("Warning");
			alert.setHeaderText(null);
			alert.setContentText("Please enter a username!");
			alert.showAndWait();
    	}
    }
    
    
    @FXML
    public void userlogin(ActionEvent event) {
    	String uname = username.getText();
    	if (!uname.equals("") && adminname.getText().equals("")) {
    		User userr = Administrator.retrieveUser(uname);
    		if (userr != null) {
    			application.gotouser(uname);
    		}else {
    			Alert alert = new Alert(AlertType.INFORMATION);
    			alert.setTitle("Warning");
    			alert.setHeaderText(null);
    			alert.setContentText("Username does not match!");
    			alert.showAndWait();
    		}    		
    		username.setText(null);
    	}else if(adminname.getText().equals("") && uname.equals("")) {
    		Alert alert = new Alert(AlertType.INFORMATION);
			alert.setTitle("Warning");
			alert.setHeaderText(null);
			alert.setContentText("Please enter a username!");
			alert.showAndWait();
    	}
    }
    
   
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }  
    
    

 
    }

