package view;

import java.net.URL;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.ResourceBundle;
import application.Photos;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import model.Album;
import model.Photo;
import javafx.scene.control.Alert;
import javafx.scene.input.MouseEvent;

public class userController implements Initializable {
	private Photos application;
	private String comuser;
	
	
	public String getComuser() {
		return comuser;
	}
	public void setComuser(String comuser) {
		this.comuser = comuser;
	}

	@FXML
	private Button create;
	@FXML
	private Button rename;
	@FXML
	private Button delete;
	@FXML
	private Button search;	
	@FXML
	private Button logout;		
	@FXML
	private TextField albumname;
	@FXML
	private TextField tagvalue;
	@FXML
	private DatePicker starttime;
	@FXML
	private DatePicker endtime;
	@FXML
	private TableView<Album> albumdisplay;
	@FXML
	private TableColumn<Album, String> albumnamecol;
	@FXML
	private TableColumn <Album, Number> albumnumcol;
	
	@FXML
	private TableView<Photo> photodisplay = new TableView<>();
	@FXML
	private TableColumn <Photo, Image> picviewcol;
	@FXML
	private TableColumn <Photo, String> photonamecol;
	@FXML
	private TableColumn <Photo, String> photoalbcol;
	@FXML
	private TableColumn <Photo, LocalDate> photodatecol;
	
	private ObservableList<Album> albumlist;
	private ObservableList<Photo> photolist;
	
	//testing list	
	static List<Album> testlista = new ArrayList<>();	
	static {
		testlista.add(new Album("album1"));
		testlista.add(new Album("album2"));
	}
		
	//testing list	
	static List<Photo> testlistb = new ArrayList<>();	
	static {
		testlistb.add(new Photo("photo1", "black", 20181119));
		testlistb.add(new Photo("photo2", "white", 20181119));
		}
	
	
	// Event Listener on Button.onAction
	@FXML
	public void createalbum(ActionEvent event) {
		if (!albumname.getText().equals("")){
			//evoke function to add an album
			testlista.add(new Album(albumname.getText()));
			showAlbum(testlista);
			albumname.setText("");			
		}else {
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setTitle("Warning");
			alert.setHeaderText(null);
			alert.setContentText("Please enter an album name!");
			alert.showAndWait();
		}
		
		
	}
	// Event Listener on Button.onAction
	@FXML
	public void renamealbum(ActionEvent event) {
		int albumIndex = albumdisplay.getSelectionModel().getSelectedIndex();
		if (!albumname.getText().equals("")) {
			//evoke function to rename an album
			testlista.get(albumIndex).setAlbumName(albumname.getText());
			showAlbum(testlista);
			albumname.setText("");
		}else {
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setTitle("Warning");
			alert.setHeaderText(null);
			alert.setContentText("Please enter an album name!");
			alert.showAndWait();
		}
		
	}
	// Event Listener on Button.onAction
	@FXML
	public void deletealbum(ActionEvent event) {
		int albumIndex = albumdisplay.getSelectionModel().getSelectedIndex();
		//evoke function to remove a user
		testlista.remove(albumIndex);
		showAlbum(testlista);		
	}
		
	// Event Listener on Button.onAction
	@FXML
	public void searchphoto(ActionEvent event) {
		if (!tagvalue.getText().equals("") && starttime.getValue() == null && endtime.getValue() == null) {
			String[] tagarray = tagvalue.getText().split(", ");
			//evoke search by tag function
			showPhoto(testlistb);
			tagvalue.setText("");
		}else if (tagvalue.getText().equals("") && starttime.getValue() != null && endtime.getValue() != null) {
			LocalDate start = starttime.getValue();
			LocalDate end = endtime.getValue();
			//evoke search by time function
			showPhoto(testlistb);
			starttime.setValue(null);
			endtime.setValue(null);
		}else if (!tagvalue.getText().equals("") && starttime.getValue() != null) {
			String[] tagarray = tagvalue.getText().split(", ");
			//evoke search by tag and by date function
			showPhoto(testlistb);
			tagvalue.setText("");
			starttime.setValue(null);
			endtime.setValue(null);
		}else {
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setTitle("Warning");
			alert.setHeaderText(null);
			alert.setContentText("Please enter tag value(s) or date range!");
			alert.showAndWait();
		}
		
	}
		
	public void setApp(Photos application){
        this.application = application;
    }
    
   @FXML
    private void logout(ActionEvent event) {
       application.gotologin();
    }
   
   public void showAlbum(List<Album> viewlist) {
	   //albumdisplay.setStyle("-fx-table-cell-border-color: transparent;");
	   //albumdisplay.setStyle("-fx-table-row-cell-border-width: 1;");
	   //evoke controller function to get a list of all user	   	   
	   albumlist = FXCollections.observableArrayList(viewlist);
	   albumnamecol.setCellValueFactory(cellData -> cellData.getValue().getAlbumTitle());
	   albumnumcol.setCellValueFactory(cellData -> cellData.getValue().getPhotoNum());
	   albumdisplay.setItems(albumlist);
   }
   
   public void showPhoto(List<Photo> viewlist) {
	   //evoke controller function to get a list of all user	   	   
	   photolist = FXCollections.observableArrayList(viewlist);
	 //set thumbnail image
	 		picviewcol.setCellFactory(param -> {
	 		       //Set up the ImageView
	 		       final ImageView imageview = new ImageView();
	 		       imageview.setFitHeight(40);
	 		       imageview.setFitWidth(40);

	 		       //Set up the Table
	 		       TableCell<Photo, Image> cell = new TableCell<Photo, Image>() {
	 		           public void updateItem(Image item, boolean empty) {
	 		             if (item != null) {
	 		                  imageview.setImage(item);
	 		             }
	 		           }
	 		        };
	 		        // Attach the imageview to the cell
	 		        cell.setGraphic(imageview);
	 		        return cell;
	 		   });
	 		
	 		picviewcol.setCellValueFactory(cellData -> new ReadOnlyObjectWrapper(cellData.getValue().getImageview(cellData.getValue().getPhotoFileName())));
	 		//picviewcol.setCellValueFactory(new PropertyValueFactory<Photo, Image>("photoview"));
	 				
	   
	   photonamecol.setCellValueFactory(cellData -> new ReadOnlyStringWrapper(cellData.getValue().getPhotoFileName()));
	   photonamecol.setCellValueFactory(cellData -> new ReadOnlyStringWrapper(cellData.getValue().getPhotoFileName()));
	   photodatecol.setCellValueFactory(cellData -> new ReadOnlyObjectWrapper(cellData.getValue().getDateOfPhoto()));
	   //photonamecol.setCellValueFactory(new PropertyValueFactory<Photo, String>("photoFileName"));
	  // photoalbcol.setCellValueFactory(new PropertyValueFactory<Photo, String>("photoFileName"));
	   //photodatecol.setCellValueFactory(new PropertyValueFactory<Photo, Long>("dateOfPhoto"));
	   photodisplay.setItems(photolist);	   
   }
   
   //double clicked an album to open it
   public void albumclick() {
		albumdisplay.setOnMouseClicked(new EventHandler<MouseEvent>() {
		    @Override
		    public void handle(MouseEvent click) {
		        if (click.getClickCount() == 2) {
		        	int albumIndex = albumdisplay.getSelectionModel().getSelectedIndex();
		        	String selectedalbum = testlista.get(albumIndex).getAlbumName();
		        	application.gotoalbum(comuser, selectedalbum);
		           
		        }
		    }
		});		
	}
	
   //double clicked photo to view it in a new page
	public void photoclick() {
		photodisplay.setOnMouseClicked(new EventHandler<MouseEvent>() {
		    @Override
		    public void handle(MouseEvent click) {
		        if (click.getClickCount() == 2) {
		        	int photoIndex = photodisplay.getSelectionModel().getSelectedIndex();
		        	String selectedphoto = testlistb.get(photoIndex).getPhotoFileName();
		        	//get the album name of which the selected photo belongs to
		        	String photocomalbum = null;
		        	application.gotophotos(comuser, photocomalbum, selectedphoto);
		           
		        }
		    }
		});		
	}
   
    @Override
    public void initialize(URL url, ResourceBundle rb) {
 
    }
}
