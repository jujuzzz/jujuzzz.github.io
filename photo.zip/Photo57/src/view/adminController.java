package view;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import model.User;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import application.Photos;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;

public class adminController implements Initializable{ 
	private Photos application;
	@FXML
	private Button add;
	@FXML
	private Button delete;
	@FXML
	private Button logout;
	@FXML
	private TextField username;
	@FXML
	private ListView<User> userdisplay = new ListView<>();
	
	private ObservableList<User> userlist;
	
	

	
	//testing list	
	static List<User> testlist = new ArrayList<>();	
	static {
		testlist.add(new User("juju"));
		testlist.add(new User("stock"));
	}
	

	
	// Event Listener on Button.onAction
	@FXML
	public void adduser(ActionEvent event) {	
		if (!username.getText().equals("")){
			//evoke function to add a user
			testlist.add(new User(username.getText()));
			showList(testlist);
			username.setText("");
		}else {
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setTitle("Warning");
			alert.setHeaderText(null);
			alert.setContentText("Please enter a username!");
			alert.showAndWait();
		}
	
		
	}
	// Event Listener on Button.onAction
	@FXML
	public void deleteuser(ActionEvent event) {		
		int userIndex = userdisplay.getSelectionModel().getSelectedIndex();
		//evoke function to remove a user
		testlist.remove(userIndex);
		showList(testlist);		
	}
	
	@FXML
	public void logout(ActionEvent event) {
		application.gotologin();
	}
    
	
   public void setApp(Photos application){
       this.application = application;
   }
   
     
   public void showList(List<User> viewlist) {
	   //evoke controller function to get a list of all user	   	   
	   userlist = FXCollections.observableArrayList(viewlist);
	   userdisplay.setItems(userlist);	   
   }
   
    @Override
    public void initialize(URL url, ResourceBundle rb) {
 
    }
}
