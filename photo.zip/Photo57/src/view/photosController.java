package view;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import java.net.URL;
import java.util.ResourceBundle;

import application.Photos;
import javafx.event.ActionEvent;

public class photosController implements Initializable {
	private Photos application;
	private String comuser;
	private String comalbum;
	private String comphoto;
	
	
	public String getComphoto() {
		return comphoto;
	}
	public void setComphoto(String comphoto) {
		this.comphoto = comphoto;
	}
	public String getComuser() {
		return comuser;
	}
	public void setComuser(String comuser) {
		this.comuser = comuser;
	}
	public String getComalbum() {
		return comalbum;
	}
	public void setComalbum(String comalbum) {
		this.comalbum = comalbum;
	}
	
	@FXML
	private Label albumname;
	@FXML
	private Label captionview;
	@FXML
	private Label datetime;
	@FXML
	private Label taglist;
	@FXML
	private Button tag;
	@FXML
	private Button deletetag;
	@FXML
	private Button caption;	
	@FXML
	private Button prepic;
	@FXML
	private Button nextpic;
	@FXML
	private Button logout;	
	@FXML
	private Button returnalbum;	
	@FXML
	private TextField captionvalue;
	@FXML
	private TextField tagvalue;
	@FXML
	private ImageView image = new ImageView();
	
	

	// Event Listener on Button.onAction
	@FXML
	public void addtag(ActionEvent event) {
		//method to add tag
		//loop to update the taglist
	}
	// Event Listener on Button.onAction
	@FXML
	public void deletetag(ActionEvent event) {
		//method to delete tag
		// loop to update the taglist
	}
	// Event Listener on Button.onAction
	@FXML
	public void caption(ActionEvent event) {
		//method to caption
		captionview.setText(captionvalue.getText());
	}
	// Event Listener on Button.onAction
	@FXML
	public void viewpre(ActionEvent event) {
		//String prephoto = 
		//showphoto
		
	}
	// Event Listener on Button.onAction
	@FXML
	public void viewnext(ActionEvent event) {
		//String prephoto = 
		//showphoto
	}
	
	public void setApp(Photos application){
        this.application = application;
    }
    
	@FXML
    private void returnalbum(ActionEvent event) {
		//if user comes from the user page, returns to user page
		if (comalbum == null) {
			application.gotouser(comuser);
		}else if (comalbum != null) {
			//if user comes from the album page, returns to album page
			application.gotoalbum(comuser, comalbum);
		}		
       
    }
	
   @FXML
    private void logout(ActionEvent event) {
       application.gotologin();
    }
   
   public void settitle() {
		albumname.setText(comalbum);
	}
   
   public void showphoto(String phototitle) {
	   Image shownphoto = new Image(phototitle);
	   image.setImage(shownphoto);
	   //show caption
	   //loop to show tag
	   //show date
	   
   }
   
   
   
    @Override
    public void initialize(URL url, ResourceBundle rb) {
 
    }
}
