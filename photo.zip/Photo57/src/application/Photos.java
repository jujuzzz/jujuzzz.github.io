package application;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.fxml.JavaFXBuilderFactory;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import model.Album;
import model.Photo;
import model.User;
import view.adminController;
import view.albumController;
import view.loginController;
import view.photosController;
import view.userController;

public class Photos extends Application {
	private Stage stage;
    private final double MINIMUM_WINDOW_WIDTH = 600.0;
    private final double MINIMUM_WINDOW_HEIGHT = 400.0;
   
    @Override
    public void start(Stage primaryStage) throws Exception {
        stage = primaryStage; 
        stage.setMinWidth(MINIMUM_WINDOW_WIDTH);
        stage.setMinHeight(MINIMUM_WINDOW_HEIGHT);
        stage.initStyle(StageStyle.DECORATED);
        stage.setTitle("Photos");
        gotologin();
        stage.show();
    }

    // go to loginController and launch login page
    public void gotologin( ){   	
        try {
              loginController login = (loginController) replaceSceneContent("/view/login.fxml");
              login.setApp(this);
          } catch (Exception ex) {
              Logger.getLogger(Photos.class.getName()).log(Level.SEVERE, null, ex);
          }
      }
    
    // go to adminController and launch admin page
    public void gotoadmin(){
        try {
               adminController adminsys = (adminController) replaceSceneContent("/view/admin.fxml");              
               adminsys.setApp(this);
               List<User> testlist = new ArrayList<>();	
           	   testlist.add(new User("juju"));
           	   testlist.add(new User("stock"));
               adminsys.showList(testlist);
           } catch (Exception ex) {
               Logger.getLogger(Photos.class.getName()).log(Level.SEVERE, null, ex);
           }
       }
    
    // go to userController and launch user page
    public void gotouser(String username){
        try {
               userController usersys = (userController) replaceSceneContent("/view/user.fxml");
               usersys.setComuser(username);
               usersys.setApp(this);
             //testing list	
           	   List<Album> testlista = new ArrayList<>();	           	
           	   testlista.add(new Album("album1"));
           	   testlista.add(new Album("album2"));
           	   usersys.showAlbum(testlista);
           	
           		
           	//testing list	
           	   List<Photo> testlistb = new ArrayList<>();	          	
           	   testlistb.add(new Photo("photo1", "black", 20181119));
           	   testlistb.add(new Photo("photo2", "white", 20181119));
           	   usersys.showPhoto(testlistb);
           	   
           	   usersys.albumclick();
           	   usersys.photoclick();
           	   
           } catch (Exception ex) {
               Logger.getLogger(Photos.class.getName()).log(Level.SEVERE, null, ex);
           }
       }    
     
     // go to album controller and launch album page     
     public void gotoalbum(String username, String albumname) {
    	 try {
             albumController album = (albumController) replaceSceneContent("/view/album.fxml");
             album.setComuser(username);
             album.setComalbum(albumname);
             album.setApp(this);
             album.settitle();
             List<Photo> testlistb = new ArrayList<>();	          	
         	 testlistb.add(new Photo("photo1", "black", 20181119));
         	 testlistb.add(new Photo("photo2", "white", 20181119));
         	 album.showPhoto(testlistb);
         	 album.photoclick();
         	 album.photorightclick();
         } catch (Exception ex) {
             Logger.getLogger(Photos.class.getName()).log(Level.SEVERE, null, ex);
         }
    	 
     }
     
     // go to photos controller and launche photos page
     public void gotophotos(String username, String albumname, String photoname) {
    	 try {
             photosController pic = (photosController) replaceSceneContent("/view/photos.fxml");
             pic.setComuser(username);
             pic.setComalbum(albumname);
             pic.setComphoto(photoname);
             pic.setApp(this);
             pic.showphoto(photoname);
         } catch (Exception ex) {
             Logger.getLogger(Photos.class.getName()).log(Level.SEVERE, null, ex);
         }
    	 
     }
     
     
     //a general method to replace fxml file and renew the scene
     private Initializable replaceSceneContent(String fxml) throws Exception {
         FXMLLoader loader = new FXMLLoader();
         InputStream in = Photos.class.getResourceAsStream(fxml);
         loader.setBuilderFactory(new JavaFXBuilderFactory());
         loader.setLocation(Photos.class.getResource(fxml));
         Pane page;
         try {
             page = (Pane) loader.load(in);
         } finally {
             in.close();
         } 
         Scene scene = new Scene(page, 600, 400);
         stage.setScene(scene);
         stage.sizeToScene();
         return (Initializable) loader.getController();
     }
     
     
     public static void main(String[] args) {
         launch(args);
     }


  
    
}
